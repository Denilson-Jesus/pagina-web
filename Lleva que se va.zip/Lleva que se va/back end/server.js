const express = require('express');
const sql = require('mssql'); // Conector oficial de Microsoft SQL Server
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors()); 

//  CONFIGURACIÓN DE ACCESO A SQL SERVER (SSMS)
const config = {
    user: 'sa',                         
    password: 'TuPasswordAqui123',      
    server: 'localhost',                
    database: 'lleva_que_se_va',        
    options: {
        encrypt: false,                 
        trustServerCertificate: true    
    }
};

//  CONECTAR DE FORMA SEGURA A LA BASE DE DATOS
sql.connect(config, err => {
    if (err) {
        console.error(' Error al conectar a SQL Server:', err);
        return;
    }
    console.log(' ¡Conectado exitosamente a SQL Server desde el Backend!');
});

//  RUTA QUE RECIBE EL PEDIDO DE LA WEB Y LO INSERTA EN SQL SERVER
app.post('/api/nuevo-pedido', async (req, res) => {
    const { nombre, direccion, telefono, categoria, producto, cantidad, entrega, observaciones } = req.body;

    try {
        const pool = await sql.connect(config);
        
        // Ejecución de la consulta SQL con parámetros seguros
        await pool.request()
            .input('nombre', sql.VarChar, nombre)
            .input('direccion', sql.VarChar, direccion)
            .input('telefono', sql.VarChar, telefono)
            .input('categoria', sql.VarChar, categoria)
            .input('producto', sql.VarChar, producto)
            .input('cantidad', sql.Int, cantidad)
            .input('entrega', sql.VarChar, entrega)
            .input('observaciones', sql.Text, observaciones)
            .query(`INSERT INTO pedidos (nombre_cliente, direccion, telefono, categoria, producto, cantidad, metodo_entrega, observaciones) 
                    VALUES (@nombre, @direccion, @telefono, @categoria, @producto, @cantidad, @entrega, @observaciones)`);

        res.status(200).json({ mensaje: '¡Pedido guardado en SQL Server con éxito!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al insertar en la base de datos.' });
    }
});

// INICIAR EL SERVIDOR
app.listen(3000, () => {
    console.log(' Servidor Backend corriendo en http://localhost:3000');
});