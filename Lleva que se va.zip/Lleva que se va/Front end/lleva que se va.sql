CREATE DATABASE lleva_que_se_va;
GO

USE lleva_que_se_va;
GO

CREATE TABLE pedidos (
    id_pedido INT IDENTITY(1,1) PRIMARY KEY, -- Autoincrementable en SQL Server
    nombre_cliente VARCHAR(100) NOT NULL,
    direccion VARCHAR(150) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    producto VARCHAR(100) NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    metodo_entrega VARCHAR(30) NOT NULL,
    observaciones TEXT NULL,
    fecha_registro DATETIME DEFAULT GETDATE() -- Fecha y hora actual del servidor
);
GO

INSERT INTO pedidos (nombre_cliente, direccion, telefono, categoria, producto, cantidad, metodo_entrega, observaciones)
VALUES 
('Juan Perez', 'Av. Larco 456', '987654321', 'Pizzas', 'Pizza Pepperoni', 1, 'delivery', 'Traer cubiertos y salsa roja.'),
('Ana Torres', 'Calle Merced 123', '951753462', 'Pollo', '1/2 Pollo', 2, 'recojo', 'Papas bien crocantes.');
GO

SELECT * FROM pedidos;