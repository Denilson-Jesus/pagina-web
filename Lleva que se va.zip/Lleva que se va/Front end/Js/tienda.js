// ====== MÓDULO DEL CARRITO DE COMPRAS ======
// Arreglo global exigido por la rúbrica
let carrito = [];
function agregarAlCarrito(nombreProducto, precio) {
    const producto = {
        nombre: nombreProducto,
        precio: precio
    };
    carrito.push(producto);
    alert(` ¡Añadido! "${nombreProducto}" se agregó correctamente al carrito.`);
    console.log("Estado actual del carrito:", carrito);
}

// ====== MÓDULO DE INTERACCIÓN GENERAL (DOM) ======
document.addEventListener("DOMContentLoaded", () => {
    
    // 1. Saludo Dinámico basado en la hora para index.html
    const bannerTitulo = document.querySelector(".banner h2");
    if (bannerTitulo) {
        const hora = new Date().getHours();
        let mensaje = "¡Bienvenido a Lleva que se va!";
        
        if (hora < 12) mensaje = " ¡Buenos días! Revisa las ofertas matutinas de hoy";
        else if (hora < 18) mensaje = " ¡Buenas tardes! Almuerza ahorrando con nosotros";
        else mensaje = " ¡Buenas noches! Aprovecha las últimas comidas del día";
        
        bannerTitulo.textContent = mensaje; 
    }

    // 2. Buscador en tiempo real para la tabla en pedidos.html
    const buscador = document.getElementById("buscador");
    if (buscador) {
        buscador.addEventListener("keyup", () => {
            const texto = buscador.value.toLowerCase();
            const filas = document.querySelectorAll("table tr:not(:first-child)");

            // Estructura Repetitiva (Bucle) para recorrer la tabla
            filas.forEach(fila => {
                const nombreCliente = fila.cells[0].textContent.toLowerCase();
                
                // Manipulación de estilos en vivo
                if (nombreCliente.includes(texto)) {
                    fila.style.display = ""; 
                } else {
                    fila.style.display = "none"; 
                }
            });
        });
    }
});