// ====== MÓDULO DE FORMULARIO DE PEDIDOS ======
// Buscamos el formulario en el HTML mediante su clase
const formularioPedido = document.querySelector('.formulario');
if (formularioPedido) {
    formularioPedido.addEventListener('submit', function(evento) {
        evento.preventDefault(); 
        const datosPedido = {
            nombre: document.getElementById('nombre').value,
            direccion: document.getElementById('direccion').value,
            telefono: document.getElementById('telefono').value,
            categoria: document.querySelector('input[name="categoria"]:checked').value,
            producto: document.getElementById('producto').value,
            cantidad: parseInt(document.getElementById('cantidad').value),
            entrega: document.querySelector('input[name="entrega"]:checked').value,
            observaciones: document.getElementById('observaciones').value
        };
        if (isNaN(datosPedido.telefono)) {
            alert(" Por favor, ingrese un número de teléfono válido (solo números).");
            return; 
        }
        fetch('http://localhost:3000/api/nuevo-pedido', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(datosPedido) 
        })
        .then(respuesta => respuesta.json())
        .then(data => {
            alert(" " + data.mensaje); 
            formularioPedido.reset(); 
        })
        .catch(error => {
            console.error('Error de conexión:', error);
            alert(" No se pudo conectar con el servidor Backend. Verifique que 'node server.js' esté ejecutándose.");
        });
    });
}

// ====== MÓDULO DE VALIDACIÓN DE INICIO DE SESIÓN (login.html) ======
const formularioLogin = document.getElementById('form-login');
if (formularioLogin) {
    formularioLogin.addEventListener('submit', function(evento) {
        const usuario = document.getElementById('usuario').value.trim();
        const contrasena = document.getElementById('contrasena').value;

        if (usuario === "" || contrasena === "") {
            evento.preventDefault();
            alert(" Por favor, complete todos los campos del inicio de sesión.");
        } else if (contrasena.length < 6) {
            evento.preventDefault();
            alert(" La contraseña de acceso debe tener un mínimo de 6 caracteres.");
        }
    });
}

// ====== MÓDULO DE VALIDACIÓN DE REGISTRO DE USUARIOS (registro.html) ======
const formularioRegistro = document.getElementById('form-registro') || document.querySelector('.formulario');

if (formularioRegistro && !document.getElementById('telefono')) { 
    formularioRegistro.addEventListener('submit', function(evento) {
        const inputsTexto = formularioRegistro.querySelectorAll('input[type="text"], input[type="email"]');
        const inputsPassword = formularioRegistro.querySelectorAll('input[type="password"]');
        if (inputsPassword.length >= 2) {
            const nuevaContrasena = inputsPassword[0].value;
            const confirmarContrasena = inputsPassword[1].value;
            let usuarioVacio = false;
            inputsTexto.forEach(input => {
                if (input.value.trim() === "") usuarioVacio = true;
            });
            if (usuarioVacio || nuevaContrasena === "" || confirmarContrasena === "") {
                evento.preventDefault(); // Detiene el envío
                alert("⚠️ Todos los campos de registro son de carácter obligatorio.");
                return;
            }
            if (nuevaContrasena !== confirmarContrasena) {
                evento.preventDefault(); // BLOQUEA el envío de la página
                alert("⚠️ Error: Las contraseñas ingresadas no coinciden entre sí. Por favor, verifíquelas.");
                return;
            }
        }
    });
}